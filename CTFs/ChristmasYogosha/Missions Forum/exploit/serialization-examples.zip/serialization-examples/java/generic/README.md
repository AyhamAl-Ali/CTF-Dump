# Deserialization examples

## Java
To more easily execute the code, visit the [repl](https://repl.it/@portswigger/java-serialization-example).
