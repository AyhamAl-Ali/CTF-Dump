// This class added just so that ProductTemplate can compile correctly

package data.productcatalog;
class Product {}
